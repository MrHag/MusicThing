import styled from "styled-components";

const TopContainer = styled.div`
  display: flex;
  height: 100%;
`;

export default TopContainer;
