import styled from "styled-components";

const BottomContainer = styled.div`
  display: flex;
`;

export default BottomContainer;
